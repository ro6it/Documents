<? 
ob_start();
header("Expires: ".-1000);
set_time_limit(200);
$sline = "<BR><BR><BR>";
$ObjOCPremote = new COM('OCPsetup.clsSetup');
$sReturn=$ObjOCPremote->TestConnection('1','216.132.25.201','216.132.25.201');
print $sReturn;
print $sline;
$sReturn=$ObjOCPremote->TestConnection('2','216.132.25.201','216.132.25.201');
print $sReturn;
print $sline;
$sReturn=$ObjOCPremote->TestConnection('3','216.132.25.201','216.132.25.201');
print $sReturn;
print $sline;
$sReturn=$ObjOCPremote->TestConnection('4','216.132.25.201','216.132.25.201');
print $sReturn;
print $sline;
$sReturn=$ObjOCPremote->TestConnection('5','216.132.25.201','216.132.25.201');
print $sReturn;
print $sline;
exit();
?>