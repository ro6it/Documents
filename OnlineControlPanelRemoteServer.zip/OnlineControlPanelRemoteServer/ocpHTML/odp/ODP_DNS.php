<? 
ob_start();
header("Expires: ".-1000);
set_time_limit(200);
$sPrams=trim($_POST["sParams"]);
$sFunction=trim($_POST["sFunction"]);

if ($sPrams == "" || $sFunction == "")
{
	$sReturn="ERROR~Invalid Function Call";
}
else
{
	$sPrams = urldecode($sPrams);
	$sCall = $sFunction . "~" . $sPrams . "~" . time();
	$ObjOCPremote = new COM('OCPremote.clsDNS');
	$sReturn = $ObjOCPremote->fnMain_clsDNS($sCall);
	$ObjOCPremote = null;

}
print $sReturn;
exit();
?>