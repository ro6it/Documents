<? 
ob_start();
header("Expires: ".-1000);
set_time_limit(200);
$sGUID=trim($_POST["GUID"]);

if ($sGUID !="")
{
	$ObjOCPremote = new COM('OCPsetup.clsSetup');
	$sReturn=$ObjOCPremote->fn_GUID($sGUID);
}
 else
{

  $sReturn="ERROR|Bad Input";
} 
print $sReturn;
exit();
?>